
Dear sir, please follow the instruction below -

Step 1:
	Go to "db" folder copy realestate.sql file
	
Step 2:
	Import the file into your localhost server and DB name will be realestate.

Step 3:
	Copy the whole folder to your localhost server and visit on your browser.




Thank you for checking..............	